<footer class="footer pt-0">
    <div class="row align-items-center">
        <div class="col">
            @if($judul_halaman === 'Admin | Dashboard')
                <div class="copyright text-center text-lg-left text-light">&copy; 2022 <a href="/" class="font-weight-bold ml-1 text-white">COLOL</a> - Powered by <a href="https://jongkreatif.id/" target="_blank" class="font-weight-bold ml-1 text-white">Jongkreatif</a>.</div>
            @else
                <div class="copyright text-center text-lg-left text-muted">&copy; 2022 <a href="/" class="font-weight-bold ml-1">COLOL</a> - Powered by <a href="https://jongkreatif.id/" target="_blank" class="font-weight-bold ml-1">Jongkreatif</a>.</div>
            @endif
        </div>
    </div>
</footer>