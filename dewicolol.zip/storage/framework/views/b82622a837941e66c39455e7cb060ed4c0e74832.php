
 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Start your development with a Dashboard for Bootstrap 4." />
        <meta name="author" content="Creative Tim" />
        <title><?php echo e($judul_halaman); ?></title>
        <!-- Favicon -->
        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($setting->favicon): ?>
        <link rel="icon" href="<?php echo e(asset('storage/' . $setting->favicon)); ?>" type="image/png" />
        <?php else: ?>
        <link rel="icon" href="<?php echo e(asset('admin/assets/img/brand/favicon.png')); ?>" type="image/png" />
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" />
        <!-- Icons -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/nucleo/css/nucleo.css')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>" type="text/css" />
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <!-- Argon CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/argon.css?v=1.1.0')); ?>" type="text/css" />
        
    </head>

    <body>
        <!-- Sidenav -->
        <nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
            <div class="scrollbar-inner">
                <!-- Brand -->
                <div class="sidenav-header d-flex align-items-center">
                    <a class="navbar-brand" href="/">
                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($setting->logo): ?>
                            <img src="<?php echo e(asset('storage/'. $setting->logo)); ?>" class="navbar-brand-img" alt="..." style="min-height: 60px; object-fit: contain;"/>
                            <?php else: ?>
                            <img src="<?php echo e(asset('admin/assets/img/brand/blue.png')); ?>" class="navbar-brand-img" alt="..." />
                            <?php endif; ?>   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </a>
                    <div class="ml-auto">
                        <!-- Sidenav toggler -->
                        <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin" data-target="#sidenav-main">
                            <div class="sidenav-toggler-inner">
                                <i class="sidenav-toggler-line"></i>
                                <i class="sidenav-toggler-line"></i>
                                <i class="sidenav-toggler-line"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="navbar-inner">
                    <!-- Collapse -->
                    <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                        <!-- Nav items -->
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(( $judul_halaman === 'Admin | Dashboard' ) ? 'active' : ''); ?> " href="/dashboard">
                                    <i class="ni ni-shop text-primary"></i>
                                    <span class="nav-link-text">Dashboard</span>
                                </a>
                            </li>
                        </ul>

                        <!-- Divider -->
                        <hr class="my-3">
                        <h6 class="navbar-heading p-0 text-primary">DATA</h6>
                        <ul class="navbar-nav mb-md-3">

                            <?php if( Auth::user()->role === 'super-admin' ): ?>
                                <li class="nav-item">
                                    <a 
                                    class="nav-link <?php echo e(( $judul_halaman === 'Admin | Data Pengguna' || $judul_halaman === 'Admin | Edit Pengguna' || $judul_halaman === 'Admin | Tambah Pengguna' || $judul_halaman === 'Admin | Detail Pengguna' ) ? 'active' : ''); ?>" 
                                    href="/dashboard/user">
                                        <i class="ni ni-circle-08 text-green"></i>
                                        <span class="nav-link-text">Pengguna</span>
                                    </a>
                                </li>
                                
                                <?php endif; ?>
                            <li class="nav-item">
                                <a 
                                class="nav-link <?php echo e(( $judul_halaman === 'Admin | Data Postingan' || $judul_halaman === 'Admin | Edit Postingan' || $judul_halaman === 'Admin | Tambah Postingan' || $judul_halaman === 'Admin | Detail Postingan' ) ? 'active' : ''); ?>" 
                                href="/dashboard/blog">
                                    <i class="ni ni-single-copy-04 text-orange"></i>
                                    <span class="nav-link-text">Blog</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a 
                                class="
                                    nav-link <?php echo e(( $judul_halaman === 'Admin | Data Galeri' || $judul_halaman === 'Admin | Edit Galeri' || $judul_halaman === 'Admin | Tambah Galeri' ) ? 'active' : ''); ?>" 
                                href="/dashboard/gallery">
                                    <i class="ni ni-album-2 text-info"></i>
                                    <span class="nav-link-text">Galeri</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a 
                                class="
                                    nav-link <?php echo e(( $judul_halaman === 'Admin | Data Menu' || $judul_halaman === 'Admin | Edit Menu' || $judul_halaman === 'Admin | Tambah Menu' ) ? 'active' : ''); ?>" 
                                href="/dashboard/section">
                                    <i class="ni ni-single-copy-04 default"></i>
                                    <span class="nav-link-text">Section</span>
                                </a>
                            </li>
                        </ul>

                        <!-- Divider -->
                        <hr class="my-3">

                        <h6 class="navbar-heading p-0 text-primary">PROFIL</h6>
                        <ul class="navbar-nav mb-md-3">
                            <li class="nav-item">
                                <a 
                                class="nav-link <?php echo e(( $judul_halaman === 'Admin | Profil Setting') ? 'active' : ''); ?>" 
                                href="/dashboard/setting">
                                    <i class="ni ni-email-83 text-red"></i>
                                    <span class="nav-link-text">Setting</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a 
                                class="nav-link <?php echo e(( $judul_halaman === 'Admin | Profil Sosial Media') ? 'active' : ''); ?>" 
                                href="/dashboard/social">
                                    <i class="ni ni-like-2 text-purple"></i>
                                    <span class="nav-link-text">Sosial Media</span>
                                </a>
                            </li>
                        </ul>

                        <!-- Divider -->
                        <hr class="my-3">

                        <ul class="navbar-nav mb-md-3">
                            <li class="nav-item">
                                
                                <form action="/logout" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" id="logout" class="nav-link border-0" data-toggle="tooltip" style="background:none; width:100%;">
                                        <i class="ni ni-button-power text-red"></i>
                                        <span class="nav-link-text ml-2">Keluar</span>
                                    </button>
                                </form>
                            </li>
                        </ul>
                        <!-- <hr class="my-3" /> -->
                    </div>
                </div>
            </div>
        </nav>
        <!-- Main content -->
        <div class="main-content" id="panel">
            <!-- Topnav -->
            <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
                <div class="container-fluid">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Navbar links -->
                        <ul class="navbar-nav align-items-center">
                            <li class="nav-item d-xl-none">
                                <!-- Sidenav toggler -->
                                <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                                    <div class="sidenav-toggler-inner">
                                        <i class="sidenav-toggler-line"></i>
                                        <i class="sidenav-toggler-line"></i>
                                        <i class="sidenav-toggler-line"></i>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        <ul class="navbar-nav align-items-center mr-md-auto">
                            <h1 class="text-white mb-0">Selamat Datang di Halaman Dashboard!</h1>
                        </ul>
                        <ul class="navbar-nav align-items-center ml-auto ml-md-0">
                            <li class="nav-item dropdown">
                                <?php if(auth()->guard()->check()): ?>
                                    <a class="nav-link pr-0" href="#"data-toggle="modal" data-target="#profil-saya">
                                        <div class="media align-items-center">
                                            <div class="media-body mr-2 d-none d-lg-block">
                                                <span class="mb-0 text-sm font-weight-bold"><?php echo e(ucwords(Auth::user()->nama)); ?></span>
                                            </div>
                                            <?php if(Auth::user()->foto_profil != null): ?>
                                                <span class="avatar avatar-sm rounded-circle">
                                                    <img alt="Image placeholder" style="width: 100%;height:100%;object-fit:cover;" src="<?php echo e(asset('storage/' . Auth::user()->foto_profil)); ?>" />
                                                </span>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('/assets/images/download.jpeg')); ?>" class="avatar rounded-circle mr-3">
                                            <?php endif; ?>
                                        </div>
                                    </a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            
            <!-- Header -->
            <?php echo $__env->yieldContent('page-header'); ?>
            
            <!-- Page content -->
            <?php echo $__env->yieldContent('page-content'); ?>

        </div>

        
        <div class="modal fade" id="profil-saya" tabindex="-1" role="dialog" aria-labelledby="profil-saya" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title" id="modal-title-default">Profil Saya</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body text-sm">
                        <?php if(Auth::user()->foto_profil != null): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->foto_profil)); ?>" alt="" class="rounded d-block mx-auto mb-4" width="150px" height="150px">
                        <?php else: ?>
                            <img src="<?php echo e(asset('/storage/foto-profil/defaultuserimage.png')); ?>" alt="" class="rounded d-block mx-auto mb-4" width="150px" height="150px">
                        <?php endif; ?>
                        <div class="row mb-3">
                            <div class="col-4">Nama</div>
                            <div class="col-8 font-weight-bold"><?php echo e(Auth::user()->nama); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">Email</div>
                            <div class="col-8 font-weight-bold"><?php echo e(Auth::user()->email); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">Pekerjaan</div>
                            <div class="col-8 font-weight-bold"><?php echo e(Auth::user()->pekerjaan); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">No. HP</div>
                            <div class="col-8 font-weight-bold"><?php echo e(Auth::user()->no_hp); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">Alamat</div>
                            <div class="col-8 font-weight-bold"><?php echo e(Auth::user()->alamat); ?></div>
                        </div>
                    </div>
                    <div class="modal-footer text-end">
                        <a href="/dashboard/user/<?php echo e(Auth::user()->id); ?>/profile-edit" class="btn btn-primary">Edit</a>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>

        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

        <!-- Argon Scripts -->
        <!-- Core -->
        <script src="<?php echo e(asset('admin/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
        <!-- Optional JS -->
        <script src="<?php echo e(asset('admin/assets/vendor/chart.js/dist/Chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/vendor/chart.js/dist/Chart.extension.js')); ?>"></script>
        
        <!-- Argon JS -->
        <script src="<?php echo e(asset('admin/assets/js/argon.js?v=1.1.0')); ?>"></script>

        
        <script src="<?php echo e(asset('admin/assets/js/sweetalert.js')); ?>"></script>

        
        <script src="<?php echo e(asset('admin/assets/js/script.js')); ?>"></script>
        
        
        <script src="//cdn.ckeditor.com/4.18.0/basic/ckeditor.js"></script>

    </body>
</html>

<?php /**PATH C:\xammp baru\htdocs\dewijongkreatif\resources\views/layouts/admin.blade.php ENDPATH**/ ?>