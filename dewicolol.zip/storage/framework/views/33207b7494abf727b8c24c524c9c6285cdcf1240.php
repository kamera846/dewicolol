<footer class="footer pt-0">
    <div class="row align-items-center">
        <div class="col">
            <?php if($judul_halaman === 'Admin | Dashboard'): ?>
                <div class="copyright text-center text-lg-left text-light">&copy; 2022 <a href="/" class="font-weight-bold ml-1 text-white">LOHA</a> - Powered by <a href="https://jongkreatif.id/" target="_blank" class="font-weight-bold ml-1 text-white">Jongkreatif</a>.</div>
            <?php else: ?>
                <div class="copyright text-center text-lg-left text-muted">&copy; 2022 <a href="/" class="font-weight-bold ml-1">LOHA</a> - Powered by <a href="https://jongkreatif.id/" target="_blank" class="font-weight-bold ml-1">Jongkreatif</a>.</div>
            <?php endif; ?>
        </div>
    </div>
</footer><?php /**PATH C:\xammp baru\htdocs\dewijongkreatif\resources\views/partials/footer-admin.blade.php ENDPATH**/ ?>