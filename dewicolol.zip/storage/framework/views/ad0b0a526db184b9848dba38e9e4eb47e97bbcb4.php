<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- HTML Meta Tags -->
        
        <?php 
        $keywords = "desa, wisata, loha, desa wisata, desa loha, wisata loha, desa wisata loha, ntt, nusa tenggara timur";
        $description = "Sejarah peradaban masyarakat penghuni kampung sowang yang berlokasi Didesa Loha, Kecamatan Pacar, Kabupaten Manggarai Barat. kampung sowang diberi nama oleh leluhur “empo” yang datang dari suku nawangkarena sebelum dijadikan sebuah tempat pemukiman."; 
        $setting = $settings[0];
        $web_url = sprintf("%s://%s%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'], $_SERVER['REQUEST_URI'])
        ?>
        
        <meta charset="utf-8" />
        <title><?php echo e($judul_halaman); ?></title>
        <meta name="description" content="<?php echo e($description); ?>">
        <meta name="keywords" content="<?php echo e($keywords); ?>">
        
        <!-- Google / Search Engine Tags -->
        <meta itemprop="name" content="<?php echo e($judul_halaman); ?>">
        <meta itemprop="description" content="<?php echo e($description); ?>">
        <meta itemprop="image" content="<?php echo e(asset('storage/' . $setting->logo)); ?>">
        
        <!-- Facebook Meta Tags -->
        <meta property="og:url" content="<?php echo e($web_url); ?>">
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo e($judul_halaman); ?>">
        <meta property="og:description" content="<?php echo e($description); ?>">
        <meta property="og:image" content="<?php echo e(asset('storage/' . $setting->logo)); ?>">
        
        <!-- Twitter Meta Tags -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo e($judul_halaman); ?>">
        <meta name="twitter:description" content="<?php echo e($description); ?>">
        <meta name="twitter:image" content="<?php echo e(asset('storage/' . $setting->logo)); ?>">
        
        <!-- Meta Tags Generated via http://heymeta.com -->
        <!-- Stylesheets -->
        <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
        <!-- Responsive File -->
        <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" />
        <!-- Color File -->
        <link href="<?php echo e(asset('assets/css/color.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('mycss.css')); ?>">

        <link href="https://fonts.googleapis.com/css2?family=Arimo:wght@400;700&family=Merriweather:ital@0;1&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="mycss.css">
        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($setting->favicon): ?>
        <link rel="icon" href="<?php echo e(asset('storage/' . $setting->favicon)); ?>" type="image/png" />
        <?php else: ?>
        <link rel="icon" href="<?php echo e(asset('admin/assets/img/brand/favicon.png')); ?>" type="image/png" />
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Responsive -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
        <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
    </head>

    <body>
        <div class="page-wrapper">
            <!-- Preloader -->
            <div class="loader-wrap">
                <div class="preloader"><div class="preloader-close">Preloader Close</div></div>
                <div class="layer layer-one"><span class="overlay"></span></div>
                <div class="layer layer-two"><span class="overlay"></span></div>
                <div class="layer layer-three"><span class="overlay"></span></div>
            </div>

            <!-- Main Header -->
            <header class="main-header header-style-one">
                <!-- Header Top -->
                <div class="header-top">
                    <div class="auto-container">
                        <div class="inner-container">
                            <?php if(sizeof($newBlogs) != 0): ?>
                            <div class="left-column">
                                <div class="text"><i class="icon-news"></i><a href="/blog/<?php echo e($newBlogs[0]->slug); ?>">Postingan Terbaru</a> <?php echo e($newBlogs[0]->judul); ?></div>
                            </div>
                            <?php endif; ?>
                            <div class="right-column">
                                <div class="phone">
                                    <a href="tel:+18526105599"><i class="fas fa-phone-volume"></i>+1 852-610-5599</a>
                                </div>
                                <ul class="header-top-menu">
                                    <li><a href="#">City Tour</a></li>
                                    <li><a href="#">Join Us</a></li>
                                    <li><a href="#">Get In Touch</a></li>
                                </ul>
                                <ul class="social-icon">
                                    <li>
                                        <a href="#"><i class="fab fa-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Header Upper -->
                <div class="header-upper">
                    <div class="auto-container">
                        <div class="inner-container">
                            <!--Logo-->
                            <div class="logo-box">
                                <div class="logo">
                                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="./"><img src="<?php echo e(asset('storage/' . $setting->logo)); ?>" alt="" style="max-height: 60px;" /></a>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <!--Nav Box-->
                            <div class="nav-outer">
                                <!--Mobile Navigation Toggler-->
                                <div class="mobile-nav-toggler"><img src="<?php echo e(asset('assets/images/icons/icon-bar-2.png')); ?>" alt="" /></div>

                                <!-- Main Menu -->
                                <nav class="main-menu navbar-expand-md navbar-light">
                                    <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                        <ul class="navigation">
                                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($setting->web_title !== null): ?>
                                                <li><a href="<?php echo e(isset($tes)?'../':'./'); ?>">Beranda</a></li>
                                                <li class="<?php if($judul_halaman == 'Tentang Kami | ' . $setting->web_title) echo "current";?>"><a href="/about">Tentang Kami</a></li>
                                                <li class="<?php if($judul_halaman == 'Galeri | ' . $setting->web_title) echo "current";?>"><a href="/gallery">Galeri</a></li>
                                                <li class="<?php if($judul_halaman == 'Blog | ' . $setting->web_title) echo "current";?>"><a href="/blog">Blog</a></li>
                                                <li class="<?php if($judul_halaman == 'Kontak Kami | ' . $setting->web_title) echo "current";?>"><a href="/contact">Kontak</a></li>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(isset($tes)?'../':'./'); ?>">Beranda</a></li>
                                            <li class="<?php echo e(($judul_halaman === 'Tentang Kami')?'current':''); ?>"><a href="/about">Tentang Kami</a></li>
                                            <li class="<?php echo e(($judul_halaman === 'Galeri')?'current':''); ?>"><a href="/gallery">Galeri</a></li>
                                            <li class="<?php echo e(($judul_halaman === 'Blog' || isset($tes))?'current':''); ?>"><a href="/blog">Blog</a></li>
                                            <li class="<?php echo e(($judul_halaman === 'Kontak Kami')?'current':''); ?>"><a href="/contact">Kontak</a></li>                                        
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Header Upper-->

                <!-- Sticky Header  -->
                <div class="sticky-header">
                    <div class="header-upper">
                        <div class="auto-container">
                            <div class="inner-container">
                                <!--Logo-->
                                <div class="logo-box">
                                    <div class="logo">
                                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="./"><img src="<?php echo e(asset('storage/' . $setting->logo)); ?>" alt="" style="max-height: 60px;" /></a>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <!--Nav Box-->
                                <div class="nav-outer">
                                    <!--Mobile Navigation Toggler-->
                                    <div class="mobile-nav-toggler"><img src="<?php echo e(asset('assets/images/icons/icon-bar-2.png')); ?>" alt="" /></div>
                                    <!-- Main Menu -->
                                    <nav class="main-menu navbar-expand-md navbar-light"></nav>
                                </div>
                                <!-- <div class="navbar-right">
                                    <div class="search-form-two">
                                        <form>
                                            <input type="search" placeholder="Ketikkan sesuatu ..." />
                                            <button type="submit"><i class="icon-search"></i></button>
                                        </form>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Sticky Menu -->

                <!-- Mobile Menu  -->
                <div class="mobile-menu">
                    <div class="menu-backdrop"></div>
                    <div class="close-btn"><span class="icon far fa-times-circle"></span></div>

                    <nav class="menu-box">
                        <div class="nav-logo">
                            <!-- <a href="./"><img src="<?php echo e(asset('assets/images/tes-logo.png')); ?>" alt="" title="" /></a> -->
                            
                        </div>
                        <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                        <!--Social Links-->
                        <div class="social-links">
                            <ul class="clearfix">
                                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($social->tipe_sosmed === 'Facebook'): ?>
                                    <li>
                                        <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-facebook-square"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->tipe_sosmed === 'Twitter'): ?>
                                    <li>
                                        <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->tipe_sosmed === 'Instagram'): ?>
                                    <li>
                                        <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-instagram"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->tipe_sosmed === 'Pinterest'): ?>
                                    <li>
                                        <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->tipe_sosmed === 'Youtube'): ?>
                                    <li>
                                        <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </nav>
                </div>
                <!-- End Mobile Menu -->

                <div class="nav-overlay">
                    <div class="cursor"></div>
                    <div class="cursor-follower"></div>
                </div>
            </header>
            <!-- End Main Header -->

            <!--Search Popup-->
            <div id="search-popup" class="search-popup">
                <div class="close-search theme-btn"><span class="far fa-times-circle"></span></div>
                <div class="popup-inner">
                    <div class="overlay-layer"></div>
                    <div class="search-form">
                        <form method="post" action="index.php">
                            <div class="form-group">
                                <fieldset>
                                    <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required />
                                    <input type="submit" value="Search Now!" class="theme-btn" />
                                </fieldset>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            
            <?php echo $__env->yieldContent('page-content'); ?>

            <!-- Main  Footer -->
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($section->slug === 'footer'): ?>
            <footer class="main-footer">
                <div class="auto-container">
                    <!--Widgets Section-->
                    <div class="widgets-section">
                        <div class="row clearfix">
                            <!--Column-->
                            <div class="column col-lg-4 col-md-6">
                                <div class="widget about-widget">
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($section->slug === 'footer'): ?>
                                    <h3 class="widget-title"><?php echo e($section->title); ?></h3>
                                    <div class="text"><?php echo $section->description; ?></div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="social-links">
                                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($social->tipe_sosmed === 'Facebook'): ?>
                                        <li>
                                            <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-facebook-square"></i></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($social->tipe_sosmed === 'Twitter'): ?>
                                        <li>
                                            <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($social->tipe_sosmed === 'Instagram'): ?>
                                        <li>
                                            <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-instagram"></i></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($social->tipe_sosmed === 'Pinterest'): ?>
                                        <li>
                                            <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($social->tipe_sosmed === 'Youtube'): ?>
                                        <li>
                                            <a href="<?php echo e($social->link_sosmed); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                                        </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column col-lg-4 col-md-6">
                                <div class="widget links-widget">
                                    <h3 class="widget-title">Navigasi</h3>
                                    <div class="widget-content">
                                        <ul>
                                            <li><a href="<?php echo e(isset($tes)?'../':'./'); ?>">Beranda</a></li>
                                            <li><a href="/about">Tentang Kami</a></li>
                                            <li><a href="/gallery">Galeri</a></li>
                                            <li><a href="/blog">Blog</a></li>
                                            <li><a href="/contact">Kontak</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column col-lg-4 col-md-6">
                                <div class="widget contact-widget">
                                    <h3 class="widget-title">Kontak Kami</h3>
                                    <div class="widget-content">
                                        <ul class="contact-info">
                                            <li>
                                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="icon"><img src="<?php echo e(asset('assets/images/icons/icon-1.png')); ?>" alt="" /></div>
                                                <div class="text">
                                                    <strong>Lokasi</strong><?php echo e($setting->lokasi); ?> <br />
                                                    
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon"><img src="<?php echo e(asset('assets/images/icons/icon-2.png')); ?>" alt="" /></div>
                                                <div class="text">
                                                    <strong>Telepon</strong>
                                                    <a href="tel:+62 823 3976 5401"><?php echo e($setting->telpon); ?></a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon"><img src="<?php echo e(asset('assets/images/icons/icon-3.png')); ?>" alt="" /></div>
                                                <div class="text">
                                                    <strong>Email</strong>
                                                    <a href="mailto:munciple@example.net"><?php echo e($setting->email); ?></a>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Footer Bottom -->
                <div class="footer-bottom">
                    <div class="auto-container">
                        <div class="wrapper-box">
                            <div class="copyright">
                                <div class="text">© 2022 <a href="/">DESA LOHA</a> - Powered by <a href="https://jongkreatif.id/">JongKreatif</a>.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!--End pagewrapper-->

        <!--Scroll to top-->
        <div class="scroll-to-top scroll-to-target" data-target="html"><span class="icon-arrow"></span></div>

        <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/owl.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/appear.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lazyload.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/scrollbar.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/TweenMax.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/swiper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.polyglot.language.switcher')); ?>.js"></script>
        <script src="<?php echo e(asset('assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/parallax-scroll.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xammp baru\htdocs\dewijongkreatif\resources\views/layouts/main.blade.php ENDPATH**/ ?>