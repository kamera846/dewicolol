

<?php $__env->startSection('page-header'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Setting</h6>
                        <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                                <li class="breadcrumb-item"><a href="/dashboard"><i class="fas fa-home"></i></a></li>
                                <li class="breadcrumb-item active" aria-current="page">Profil Setting</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-lg-8 col-md-10">
                <div class="card">
                    <!-- Card header -->
                    <div class="card-header">
                        <h3 class="mb-0">Profil Setting</h3>
                    </div>
                    
                    
                    <div class="flash-data" data-flashdata="<?php echo e((session()->has('success'))?session('success'):''); ?><?php echo e((session()->has('error'))?session('error'):''); ?>"></div> 
                    <!-- Card Body -->
                    <div class="card-body">
                        <div class="row">
                          <div class="col">
                              <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <form action="/dashboard/contact/<?php echo e($contact->id); ?>/update" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                  <div class="form-group row">
                                    <label for="email" class="col-md-3 col-form-label form-control-label">Alamat Email</label>
                                    <div class="col-md-9">
                                      <input class="form-control form-control-alternative" type="email" id="email" name="email" value="<?php echo e($contact->email); ?>" readonly>
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <label for="no_telp" class="col-md-3 col-form-label form-control-label">Nomor Telepon</label>
                                    <div class="col-md-9">
                                      <input class="form-control form-control-alternative" type="number" id="no_telp" name="telpon" value="<?php echo e($contact->telpon); ?>" readonly>
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <label for="logo" class="col-md-3 col-form-label form-control-label">Logo</label>
                                    <input type="hidden" name="oldLogo" value="<?php echo e($contact->logo); ?>">
                                    <div class="col-md-9">
                                      <input class="form-control form-control-alternative" type="file" id="logo" name="logo" value="<?php echo e($contact->logo); ?>" readonly>
                                      <img id="image-preview-update-2" src="<?php echo e(asset('storage/' . $contact->logo)); ?>" height="100px" class="rounded mt-2" alt="...">
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <label for="lokasi" class="col-md-3 col-form-label form-control-label">Lokasi</label>
                                    <div class="col-md-9">
                                      <textarea class="form-control form-control-alternative" name="lokasi" id="lokasi" rows="3" readonly><?php echo e($contact->lokasi); ?></textarea>
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <div class="col-md-3"></div>
                                    <div class="col-md-9" id="pembungkus">
                                      <button type="button" class="btn btn-primary" id="edit">Edit</button>
                                    </div>
                                  </div>
                                </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <form action="/dashboard/contact/<?php echo e($contact->id); ?>/update" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                  <div class="form-group row">
                                    <label for="email" class="col-md-3 col-form-label form-control-label">Alamat Email</label>
                                    <div class="col-md-9">
                                      <input class="form-control form-control-alternative" type="email" id="email" name="email" value="}" readonly>
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <label for="no_telp" class="col-md-3 col-form-label form-control-label">Nomor Telepon</label>
                                    <div class="col-md-9">
                                      <input class="form-control form-control-alternative" type="number" id="no_telp" name="telpon" value="}" readonly>
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <label for="logo" class="col-md-3 col-form-label form-control-label">Logo</label>
                                    <input type="hidden" name="oldLogo" value="">
                                    <div class="col-md-9">
                                      <input class="form-control form-control-alternative" type="file" id="logo" name="logo" value="}" readonly>
                                      <img id="image-preview-update-2" src="<?php echo e(asset('storage/' . $contact->logo)); ?>" height="100px" class="rounded mt-2" alt="...">
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <label for="lokasi" class="col-md-3 col-form-label form-control-label">Lokasi</label>
                                    <div class="col-md-9">
                                      <textarea class="form-control form-control-alternative" name="lokasi" id="lokasi" rows="3" readonly></textarea>
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                    <div class="col-md-3"></div>
                                    <div class="col-md-9" id="pembungkus">
                                      <button type="button" class="btn btn-primary" id="edit">Edit</button>
                                    </div>
                                  </div>
                                </form>

                                <?php endif; ?>
                            </div>
                        </div>
                      </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('partials.footer-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammp baru\htdocs\dewijongkreatif\resources\views/dashboard/contact.blade.php ENDPATH**/ ?>