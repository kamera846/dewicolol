

<?php $__env->startSection('page-content'); ?>
<?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php 
$image = json_decode($section->cover);
?>
<?php if($section->slug === 'gallery'): ?>
    <section class="page-title" style="background-image: url(<?= asset($image != null ? 'storage/'.$image[0] : 'assets/images/background/bg-4.jpg') ?>)">
        <div class="drop-layer-gallery"></div>
        <div class="auto-container">
            <div class="content-box">
                <div class="content-wrapper">
                    <div class="title">
                        <h1 style="z-index: 3"><?php echo e($section->title); ?></h1>
                    </div>
                    <ul class="bread-crumb" style="z-index: 3">
                        <li><a href="./">Beranda</a></li>
                        <li><?php echo e($section->title); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- News section Three -->
    <section class="news-section-three">
        <div class="auto-container">

            <?php if($jumlah_galeri >= 1 ): ?>
                
                <div class="row">
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-6 news-block">
                            <div class="inner-box">
                                <div class="image">
                                    <img src="<?php echo e(asset('storage/' . $gallery->foto)); ?>" alt="<?php echo e($gallery->judul); ?>"/>
                                    <div class="overlay">
                                        <div class="link-btn">
                                            <a target="_blank" href="<?php echo e(asset('storage/' . $gallery->foto)); ?>"><i class="icon-arrow"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h4><?php echo e($gallery->judul); ?></h4>
                                    <div class="text"><?php echo e($gallery->deskripsi); ?></div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Post Pagination -->
                

                <div class="row justify-content-center mt-3">
                    <?php echo e($galleries->links()); ?>

                </div>

            <?php else: ?>

                <div class="col-12">
                    <h3 class="text-center">Belum ada Galeri.</h3>
                </div>

            <?php endif; ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammp baru\htdocs\dewijongkreatif\resources\views/gallery.blade.php ENDPATH**/ ?>