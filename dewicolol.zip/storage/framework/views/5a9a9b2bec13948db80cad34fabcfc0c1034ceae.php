


<?php $__env->startSection('page-content'); ?>
    <!-- Bnner Section -->
    <section class="banner-section">
        <div class="swiper-container banner-slider">
            <div class="swiper-wrapper" style="z-index: -1">
                <!-- Slide Item -->
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($section->slug === 'carousel-1' && $section->isActive == 'true'): ?>
                <?php 
                    $image = json_decode($section->cover);
                ?>
                <div class="swiper-slide" style="background-image: url(<?= asset($image != null ? 'storage/'.$image[0] : 'assets/images/background/bg-4.jpg') ?>)">
                    <div class="drop-layer"></div>
                    <div class="content-outer">
                        <div class="content-box justify-content-center">
                            <div class="inner text-center inner-corousel">
                                <h1>
                                    <?php echo e($section->title); ?>

                                    <br />
                                    
                                </h1>
                                <div class="text">
                                   <?php echo $section->description; ?><br />
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <!-- Slide Item -->
                <?php if($section->slug === 'carousel-2' && $section->isActive == 'true'): ?>
                <?php 
                    $image = json_decode($section->cover);
                ?>
                <div class="swiper-slide" style="background-image: url(<?= asset($image != null ? 'storage/'.$image[0] : 'assets/images/background/bg-4.jpg') ?>)">
                    <div class="drop-layer"></div>
                    <div class="content-outer">
                        <div class="content-box justify-content-center">
                            <div class="inner text-center">
                                <h1>
                                    <?php echo e($section->title); ?>

                                    <br />
                                    
                                </h1>
                                <div class="text">
                                    <?php echo $section->description; ?><br />
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <!-- Slide Item -->
                <?php if($section->slug === 'carousel-3' && $section->isActive == 'true'): ?>
                <?php 
                    $image = json_decode($section->cover);
                ?>
                <div class="swiper-slide" style="background-image: url(<?= asset($image != null ? 'storage/'.$image[0] : 'assets/images/background/bg-4.jpg') ?>)">
                    <div class="drop-layer"></div>
                    <div class="content-outer">
                        <div class="content-box">
                            <div class="inner">
                                <h1>
                                    <?php echo e($section->title); ?> <br />
                                </h1>
                                <div class="text">
                                    <?php echo $section->description; ?><br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="banner-slider-nav">
            <div class="banner-slider-control banner-slider-button-prev">
                <span><i class="icon-arrow"></i></span>
            </div>
            <div class="banner-slider-control banner-slider-button-next">
                <span><i class="icon-arrow"></i></span>
            </div>
        </div>
    </section>
    <!-- End Bnner Section -->

<!-- About section -->
<?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($section->slug === 'about' && $section->isActive == 'true'): ?>
<section class="about-section">
    <div class="auto-container">
            <div class="sec-title text-center">
                <!-- <div class="sub-title">City With Equity - Efficiency - Opportunity</div> -->
                <h2><?php echo e($section->title); ?></h2>
            </div>
            <div class="row">
                <div class="col-lg-5">
                    <div class="content-block wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="text" style="text-align:justify; text-indent: 2rem">
                            "<?php echo $section->description; ?>"
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="image-block wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="row">
                            <?php $image = json_decode($section->cover); ?>
                            <div class="col-lg-6 column">
                                <?php if($image != null): ?>
                                <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index < 2): ?>
                                        <div class="image"><img src="<?php echo e(asset('storage/' . $item)); ?>" alt="" style="height: 190px;object-fit: cover;" width="100%"/></div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-6 column">
                                <?php if($image != null): ?>
                                <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index === 2): ?>
                                        <div class="image"><img src="<?php echo e(asset('storage/' . $item)); ?>" alt="" style="height: 390px;object-fit: cover;" width="100%"/></div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <!-- Projects section -->
    <section class="projects-section">
        <div class="auto-container">
            <div class="row no-gutters">
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($section->slug === 'produk-1' || $section->slug === 'produk-2' || $section->slug === 'produk-3' || $section->slug === 'produk-4'): ?>
                <div class="col-xl-3 col-lg-6 project-block">
                    <div class="inner-box" style="height: 300px">
                            <?php $image = json_decode($section->cover); ?>
                            <div class="image" style="height: 100%; background-color: black"><img src="<?= $section->cover != null ? asset('storage/'.$image[0]) : asset('assets/images/resource/image-5.jpg'); ?>" alt="" style="height: 100%; object-fit:cover; opacity: 0.6;" /></div>
                            <div class="content" >
                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4><?php echo e($item->web_title); ?></h4>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h3><?php echo e($section->title); ?></h3>
                                <!-- <div class="link-btn">
                                    <a href="#"><i class="icon-arrow"></i></a>
                                </div> -->
                            </div>
                            <div class="overlay" >
                                <div class="content-two">
                                    <div class="text">
                                        <?php echo $section->description; ?>

                                    </div>
                                    <!-- <div class="link-btn">
                                        <a href="#"><i class="icon-arrow"></i></a>
                                    </div> -->
                                </div>
                            </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Highlights section -->
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($section->slug === 'gallery'): ?>
    <?php if($jumlah_galeri != 0): ?>
        <section class="highlights-section">
            <div class="auto-container">
                <div class="sec-title">
                    <!-- <div class="sub-title">City With Equity - Efficiency - Opportunity</div> -->
                    <h2><?php echo e($section->title); ?></h2>
                </div>
                <div class="highlight-block-area">
                    <div class="row">
                        <div class="col-lg-7">
                            <div class="text-blcok">
                                <div class="text" style="text-align: justify;">
                                    <?php echo $section->description; ?>  <br />
                                </div>
                                <?php if($jumlah_galeri > 4): ?>
                                <div class="link-btn">
                                    <a href="/gallery" class="theme-btn btn-style-one"><span>Selengkapnya</span></a>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="swiper-container highlight-thumbs">
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide">
                                            <div class="thumb"><img src="<?php echo e(asset('storage/'.$gallery->foto)); ?>" alt="" /></div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="highlight-slider-nav">
                                <div class="highlight-slider-control highlight-slider-button-prev">
                                    <span><i class="icon-arrow"></i></span>
                                </div>
                                <div class="highlight-slider-control highlight-slider-button-next">
                                    <span><i class="icon-arrow"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <!-- Swiper -->
                            <div class="swiper-container highlight-image" style="margin: inherit;">
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide">
                                            <div class="image"><img src="<?php echo e(asset('storage/'.$gallery->foto)); ?>" alt="" style="max-height: 70vh; min-height: 70vh; object-fit: cover"  width="100%" /></div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Contact Info section -->
    <section class="contact-info-section" style="margin-top: 210px; padding: 0">
        <div class="auto-container">
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
                $image = json_decode($section->cover);
            ?>
            <?php if($section->slug === 'help'): ?>
                <div class="wrapper-box" style="background-image: url(<?= asset($image != null ? 'storage/'.$image[0] : 'assets/images/background/bg-4.jpg') ?>); padding: 0; padding-top: 90px; padding-bottom: 60px;">
                <div class="drop-layer"></div>
                <div class="top-content" style="padding-left: 50px; padding-right: 50px;">
                    <h2><?php echo e($section->title); ?></h2>
                    <div class="text">
                          <?php echo $section->description; ?><br />
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row justify-content-center" style="padding-left: 50px; padding-right: 50px;">
                    <div class="col-lg-6 col-md-6 contact-info-block">
                        <div class="inner-box">
                            <div class="icon"><span class="pe-7s-call"></span></div>
                            <h5>Call us</h5>
                            <h4><a href="tel:8526105599"><?php echo e($setting->telpon); ?></a></h4>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 contact-info-block">
                        <div class="inner-box">
                            <div class="icon"><span class="pe-7s-mail-open"></span></div>
                            <h5>Send Email</h5>
                            <h4><a href="mailto:mail@govern.net"><?php echo e($setting->email); ?></a></h4>
                        </div>
                    </div>
                    <!-- <div class="col-lg-3 col-md-6 contact-info-block">
                        <div class="inner-box">
                            <div class="icon"><span class="pe-7s-stopwatch"></span></div>
                            <h5>Office Hours</h5>
                            <h4>0900am - 0600pm</h4>
                        </div>
                    </div> -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- News Section -->
    <section class="news-section">
        <div class="auto-container">
            <div class="sec-title text-center">
                <!-- <div class="sub-title">City With Equity - Efficiency - Opportunity</div> -->
                <h2>Blog Terbaru</h2>
            </div>
            <div class="row">

                <?php if($jumlah_blog >= 1): ?>
                    
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-4 col-md-6 news-block">
                            <div class="inner-box">
                                <div class="image-two">
                                    <img src="<?php echo e(asset('storage/'.$blog->gambar_blog)); ?>" alt="<?php echo e($blog->judul); ?>" class="img"/>
                                    <div class="overlay">
                                        <div class="link-btn">
                                            <a href="/blog/<?php echo e($blog->slug); ?>"><i class="icon-arrow"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <!-- <div class="category"><a href="#">Health & Fitness</a></div> -->
                                    <h4>
                                        <a href="/blog/<?php echo e($blog->slug); ?>"><?php echo e($blog->judul); ?></a>
                                    </h4>
                                    <div class="text">
                                        <?php echo e(substr(strip_tags($blog->konten), 0, 79)); ?>...
                                    </div>
                                    <ul class="post-meta">
                                        <li><i class="far fa-user"></i><?php echo e(ucwords($blog->penulis)); ?></li>
                                        <li><i class="far fa-calendar"></i><?php echo e($blog->created_at->isoFormat('d MMMM')); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                    <div class="col-12">
                        <h3 class="text-center">(Belum ada postingan)</h3>
                    </div>

                <?php endif; ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammp baru\htdocs\dewicolol\resources\views/index.blade.php ENDPATH**/ ?>